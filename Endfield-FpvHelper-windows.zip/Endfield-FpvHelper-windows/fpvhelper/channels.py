"""输入层 + 软映射层。

原则：程序里不写死"第几路是油门"。设备只提供一串通道，通道叫什么、怎么用，
全在 mapping.toml 里配。换遥控器只改配置，不改代码。

后端：
  evdev  —— Linux 输入子系统，内核已经把 HID 归一化成 ABS_X..ABS_THROTTLE + 按键。
            OpenTX/EdgeTX 的 USB 摇杆模式都是这套，跨遥控器最稳。
  hidraw —— 原始 HID 报告，按 (偏移, 宽度, 字节序, 通道数) 解。给 evdev 看不到的通道用，
            换手柄时可能要改这几个数，但改的是配置不是代码。
  joy    —— pygame(SDL) 游戏控制器。Windows / macOS 上遥控器插 USB 走的就是这条路，
            轴被 SDL 归一化成浮点，这里再放大回整数域。
  serial —— CRSF/ELRS 串口，16 通道全量，先留接口。
"""
from __future__ import annotations

import glob
import math
import os
import queue
import select
import sys
import threading
import time

try:
    import evdev
    from evdev import ecodes as e
except ImportError:  # evdev 缺失不影响 hidraw 后端
    evdev = None


# ---------------------------------------------------------------- 数据结构

class Channel:
    """一路物理通道。label 只是给人看的，程序逻辑不依赖它。"""
    __slots__ = ('index', 'label', 'min', 'max', 'value')

    def __init__(self, index, label, lo, hi, value=0):
        self.index, self.label = index, label
        self.min, self.max = lo, hi
        self.value = value

    def __repr__(self):
        return f'<ch{self.index} {self.label} {self.min}..{self.max}={self.value}>'


class Frame:
    """一次采样：各通道原始值 + 按键位图。"""
    __slots__ = ('t', 'values', 'buttons')

    def __init__(self, t, values, buttons):
        self.t, self.values, self.buttons = t, values, buttons


# ---------------------------------------------------------------- evdev 后端

_PREFERRED_AXES = ('ABS_X', 'ABS_Y', 'ABS_Z', 'ABS_RX', 'ABS_RY', 'ABS_RZ',
                   'ABS_THROTTLE', 'ABS_RUDDER', 'ABS_WHEEL', 'ABS_GAS', 'ABS_BRAKE', 'ABS_MISC')


class EvdevSource:
    name = 'evdev'

    def __init__(self, match='', path=None):
        self.path = path or self._find(match)
        self.dev = evdev.InputDevice(self.path)
        self.device_name = self.dev.name
        self._caps = self.dev.capabilities(absinfo=True)
        self.keys = sorted(self._caps.get(e.EV_KEY, []))
        self.channels = self._build_channels()

    @staticmethod
    def _find(match):
        cands = []
        for p in evdev.list_devices():
            try:
                d = evdev.InputDevice(p)
            except OSError:
                continue
            if e.EV_ABS not in d.capabilities():
                continue
            cands.append((match.lower() in d.name.lower() if match else False, d.name, p))
        if not cands:
            raise RuntimeError('没找到任何带轴的输入设备')
        cands.sort(key=lambda c: (not c[0], c[1]))
        return cands[0][2]

    def _build_channels(self):
        absinfo = {code: info for code, info in self._caps.get(e.EV_ABS, [])}
        order = []
        for want in _PREFERRED_AXES:
            code = e.ecodes.get(want)
            if code in absinfo:
                order.append(code)
        for code in sorted(absinfo):
            if code not in order:
                order.append(code)
        chans = []
        for i, code in enumerate(order):
            info = absinfo[code]
            name = e.ABS.get(code, f'ABS_{code}')
            chans.append(Channel(i, name, info.min, info.max, info.value))
        return chans

    def poll(self, timeout=0.2):
        """读到完整的 SYN_REPORT 就返回一帧，超时返回 None。"""
        r, _, _ = select.select([self.dev.fd], [], [], timeout)
        if not r:
            return None
        buttons = None
        try:
            for ev in self.dev.read():
                if ev.type == e.EV_ABS:
                    for c in self.channels:
                        if e.ABS.get(ev.code) == c.label:
                            c.value = ev.value
                elif ev.type == e.EV_KEY and ev.value in (0, 1):
                    buttons = self._buttons()
                elif ev.type == e.EV_SYN and ev.code == e.SYN_REPORT:
                    if buttons is None:
                        buttons = self._buttons()
                    return Frame(time.monotonic(),
                                 {c.index: c.value for c in self.channels}, buttons)
        except OSError:
            return None
        return None

    def _buttons(self):
        try:
            active = set(self.dev.active_keys(verbose=False))
        except OSError:
            return 0
        bits = 0
        for i, k in enumerate(self.keys):
            if k in active:
                bits |= 1 << i
        return bits

    def pressable(self):
        return [_name(k) for k in self.keys]

    def describe(self):
        lines = [f'evdev 设备 {self.path}  {self.dev.name}']
        for c in self.channels:
            lines.append(f'  ch{c.index} {c.label:<14} {c.min}..{c.max} 当前 {c.value}')
        lines.append(f'  按键 {len(self.keys)} 个: ' + ', '.join(self.pressable()[:12]))
        return '\n'.join(lines)


# ---------------------------------------------------------------- hidraw 后端

class HidrawSource:
    """原始 HID 报告。通道布局由 min/max/offset/width/endian/count 描述，全在配置里。"""
    name = 'hidraw'

    def __init__(self, match='', path=None, offset=1, width=2, endian='little', count=8):
        self.path = path or self._find(match)
        self.device_name = ''
        self.offset, self.width, self.endian, self.count = offset, width, endian, count
        self.fd = os.open(self.path, os.O_RDONLY | os.O_NONBLOCK)
        self.channels = [Channel(i, f'raw{i}', 0, 2 ** (8 * width) - 1, 0) for i in range(count)]
        self._u16 = (lambda b, o: b[o] | (b[o + 1] << 8)) if endian == 'little' else \
                    (lambda b, o: (b[o] << 8) | b[o + 1])

    @staticmethod
    def _find(match):
        for p in sorted(glob.glob('/sys/class/hidraw/hidraw*')):
            try:
                uevent = open(os.path.join(p, 'device', 'uevent')).read()
            except OSError:
                continue
            name = ''
            for line in uevent.splitlines():
                if line.startswith('HID_NAME='):
                    name = line.split('=', 1)[1]
            if match and match.lower() in name.lower():
                return '/dev/' + os.path.basename(p)
        raise RuntimeError(f'未找到匹配 "{match}" 的 hidraw 设备，可用 fpv_monitor.py --list 查看')

    def poll(self, timeout=0.2):
        r, _, _ = select.select([self.fd], [], [], timeout)
        if not r:
            return None
        try:
            data = os.read(self.fd, 64)
        except BlockingIOError:
            return None
        if len(data) < self.offset + self.count * (self.width // 2) * 2:
            return None
        vals = {}
        for i in range(self.count):
            off = self.offset + i * self.width
            raw = self._u16(data, off) if self.width == 2 else data[off]
            vals[i] = raw
            self.channels[i].value = raw
        buttons = int.from_bytes(data[-2:], 'little') if self.width == 2 else 0
        return Frame(time.monotonic(), vals, buttons)

    def describe(self):
        return (f'hidraw 设备 {self.path}\n' + '\n'.join(
            f'  ch{c.index} {c.label} {c.min}..{c.max} 当前 {c.value}' for c in self.channels))


# ---------------------------------------------------------------- joy 后端（pygame / SDL）

_PYGAME = None


def _pygame(required=False):
    """pygame 只有 joy 后端用得上，缺了就当没有，别拖累 evdev / hidraw。
    第一次 import 之前先关掉它那句社区横幅，免得混进界面的输出里。"""
    global _PYGAME
    if _PYGAME is False:
        if required:
            raise RuntimeError('joy 后端要 pygame，装一下：pip install pygame')
        return None
    if _PYGAME is None:
        os.environ.setdefault('PYGAME_HIDE_SUPPORT_PROMPT', '1')
        try:
            import pygame
        except ImportError:
            _PYGAME = False
            if required:
                raise RuntimeError('joy 后端要 pygame，装一下：pip install pygame')
            return None
        _PYGAME = pygame
    return _PYGAME


class JoySource:
    """游戏控制器后端，走 pygame(SDL)。

    Windows 上遥控器切到 USB 摇杆模式后就是个普通游戏控制器，SDL 能直接读到轴和按键，
    不用碰 /dev 也不用装驱动；Linux / macOS 上同一份代码也能跑，代价是拿不到原始量程。
    SDL 的轴是 -1..1 的浮点，这里放大回 -32767..32767 的整数域，好让 mapping.toml 里的
    min/max/center 与 evdev 后端通用：中位是 0，满量程 32767。

    这里所有的 SDL 调用都关在一个独立线程里跑，不是可选项：SDL 的 Windows 后端在
    SDL_PumpEvents 里会 PeekMessage(PM_REMOVE) + DispatchMessage 整个线程消息队列，
    跟 tkinter 挤在同一个线程就会互抢消息——拖动窗口时 Tk 收不到自己的消息，轻则卡顿，
    重则直接崩。PeekMessage 只看得到调用者自己线程的队列，所以 SDL 挪进子线程后，
    主线程（Tk）的消息一条都动不到。
    """
    name = 'joy'
    SCALE = 32767
    PUMP_HZ = 400            # 要比上层 250 Hz 的发送节拍快，保证每次发包拿到的都是新样本

    def __init__(self, match='', path=None):
        pygame = _pygame(required=True)
        self._pg = pygame
        if (sys.platform.startswith('linux')
                and not (os.environ.get('DISPLAY') or os.environ.get('WAYLAND_DISPLAY'))):
            os.environ.setdefault('SDL_VIDEODRIVER', 'dummy')   # 无头机器上别去够 X，省一串噪音
        self._frames = queue.Queue(maxsize=1)    # 只留最新一帧，旧的自动丢
        self._stop = threading.Event()
        self._ready = threading.Event()
        self._fail = None
        self.dead = False                        # 泵线程掉线后置位，界面据此提示重连
        self._th = threading.Thread(target=self._run, args=(match, path),
                                    name='fpv-joy', daemon=True)
        self._th.start()
        if not self._ready.wait(8.0):
            self._stop.set()
            raise RuntimeError('joy 后端启动超时：SDL 初始化没能在 8 秒内返回')
        if self._fail:
            raise RuntimeError(self._fail)
        self.dev = self                          # 界面里统一按 .dev.close() 收尾

    # ------------------------------------------------------------ 后台线程

    def _run(self, match, path):
        """SDL 的初始化、泵事件、采样、退出全在这个线程里完成，别处一律不碰 SDL。"""
        pg = self._pg
        try:
            try:
                # SDL 的摇杆值是靠泵事件刷新的，而泵事件要求 video 子系统先起来（不出窗口）。
                # 无头环境下起不来也无所谓，poll 会一直拿不到帧，界面上就是「连不上」。
                pg.display.init()
            except Exception:
                pass
            pg.joystick.init()
            joy = self._open(match, path)
            self.joy = joy
            try:
                guid = joy.get_guid()
            except Exception:
                guid = ''
            self.path = path or f'joy:{guid or joy.get_instance_id()}'
            self.device_name = joy.get_name()
            self.hats = joy.get_numhats()
            self.keys = [f'btn{i}' for i in range(joy.get_numbuttons())]
            self.channels = [Channel(i, f'axis{i}', -self.SCALE, self.SCALE, 0)
                             for i in range(joy.get_numaxes())]
        except Exception as exc:
            self._fail = str(exc) or type(exc).__name__
            self._ready.set()
            return
        self._ready.set()

        period = 1.0 / self.PUMP_HZ
        while not self._stop.is_set():
            t0 = time.monotonic()
            try:
                pg.event.pump()
                vals, buttons = self._sample()
            except Exception:
                self.dead = True                 # 掉线了，交给上层重连
                break
            try:
                self._frames.get_nowait()        # 丢掉没被取走的旧帧，只留最新
            except queue.Empty:
                pass
            try:
                self._frames.put_nowait(Frame(time.monotonic(), vals, buttons))
            except queue.Full:
                pass
            time.sleep(max(0.0, period - (time.monotonic() - t0)))

        try:
            pg.joystick.quit()
        except Exception:
            pass

    def close(self):
        """停掉后台线程，SDL 子系统由那个线程自己收尾。"""
        self._stop.set()
        th = getattr(self, '_th', None)
        if th is not None and th.is_alive() and th is not threading.current_thread():
            th.join(timeout=2.0)

    def _open(self, match, path):
        pg = self._pg
        count = pg.joystick.get_count()
        if not count:
            raise RuntimeError('没找到游戏控制器：遥控器切到 USB 摇杆模式再插，'
                               'Linux 上也可以改用 evdev / hidraw 后端')
        want = path[4:] if (path or '').startswith('joy:') else ''
        fallback = None
        for i in range(count):
            j = pg.joystick.Joystick(i)
            try:
                j.init()
            except Exception:
                continue
            if want:
                try:
                    if j.get_guid() == want:
                        return j
                except Exception:
                    pass
                if str(j.get_instance_id()) == want:
                    return j
                continue
            if match and match.lower() in j.get_name().lower():
                return j
            if fallback is None:
                fallback = j
        if fallback is not None:
            return fallback
        raise RuntimeError(f'没找到匹配 "{match or want}" 的游戏控制器')

    def poll(self, timeout=0.0):
        """取最新的一帧。SDL 在后台线程里泵，这里只搬数据，碰不到消息队列。

        语义跟 evdev 那边对齐：没有更新的帧就返回 None。上层的发送节拍不受影响——
        poll_input 拿不到新帧时会用手上那帧照常发。
        """
        frame = None
        while True:
            try:
                frame = self._frames.get_nowait()    # 积压的只留最后一帧
            except queue.Empty:
                break
        if frame is None and timeout > 0:
            try:
                frame = self._frames.get(timeout=timeout)
            except queue.Empty:
                return None
        return frame

    def _sample(self):
        vals = {}
        for i in range(len(self.channels)):
            v = int(round(max(-1.0, min(1.0, self.joy.get_axis(i))) * self.SCALE))
            vals[i] = v
            self.channels[i].value = v
        buttons = 0
        for i in range(len(self.keys)):
            if self.joy.get_button(i):
                buttons |= 1 << i
        return vals, buttons

    def pressable(self):
        return list(self.keys)

    def describe(self):
        lines = [f'joy 设备 {self.path}  {self.device_name}']
        for c in self.channels:
            lines.append(f'  ch{c.index} {c.label:<14} {c.min}..{c.max} 当前 {c.value}')
        lines.append(f'  按键 {len(self.keys)} 个，帽 {self.hats} 个')
        return '\n'.join(lines)


# ---------------------------------------------------------------- 串口后端（预留）

class SerialSource:
    """CRSF/ELRS 串口：16 通道 11 位打包，帧头 0xC8，长度 24。等真要用再实现。"""
    name = 'serial'

    def __init__(self, *a, **kw):
        raise NotImplementedError('CRSF 串口后端还没写：需要 pyserial，帧格式 0xC8 + 22 字节 11 位通道')


def default_backend():
    """没写 backend 时用哪个：Windows / macOS 上只有 joy 这条路能走。"""
    if sys.platform.startswith('win'):
        return 'joy'
    if sys.platform == 'darwin':
        return 'joy'
    return 'evdev'


def open_source(cfg):
    """按配置开一个输入源。cfg 是 mapping.toml 里的 [device]/[hidraw] 段。"""
    backend = (cfg.get('backend') or default_backend()).lower()
    if backend == 'hidraw':
        h = cfg.get('hidraw', {})
        return HidrawSource(cfg.get('match', ''), h.get('path') or cfg.get('path'),
                            h.get('offset', 1), h.get('width', 2),
                            h.get('endian', 'little'), h.get('count', 8))
    if backend == 'serial':
        return SerialSource()
    if backend in ('joy', 'pygame', 'sdl'):
        return JoySource(cfg.get('match', ''), cfg.get('path'))
    if backend == 'evdev':
        return EvdevSource(cfg.get('match', ''), cfg.get('path'))
    raise RuntimeError(f'不认识的 backend：{backend}（可选 evdev / hidraw / joy）')


def list_devices():
    out = []
    if evdev:
        for p in evdev.list_devices():
            try:
                d = evdev.InputDevice(p)
            except OSError:
                continue
            if e.EV_ABS in d.capabilities():
                out.append((p, d.name + '  [evdev]',
                            [e.ABS[c] for c, _ in d.capabilities(absinfo=True)[e.EV_ABS]]))
    for p in sorted(glob.glob('/sys/class/hidraw/hidraw*')):
        try:
            name = [l.split('=', 1)[1] for l in open(os.path.join(p, 'device', 'uevent'))
                    if l.startswith('HID_NAME=')][0].strip()
        except (OSError, IndexError):
            continue
        out.append(('/dev/' + os.path.basename(p), name + '  [hidraw]', []))
    out.extend(_list_joysticks())
    return out


def _list_joysticks():
    """SDL 能看到的游戏控制器。pygame 缺失就直接跳过，不当成错误。"""
    pygame = _pygame()
    if pygame is None:
        return []
    out = []
    try:
        pygame.joystick.init()
        for i in range(pygame.joystick.get_count()):
            j = pygame.joystick.Joystick(i)
            j.init()
            try:
                guid = j.get_guid()
            except Exception:
                guid = str(i)
            axes = [f'axis{k}' for k in range(j.get_numaxes())]
            out.append((f'joy:{guid}', j.get_name() + '  [joy]', axes))
    except Exception:
        return out
    return out



def _name(code):
    """ecodes 里有别名时会返回元组，这里统一拿第一个名字。"""
    if code in e.KEY:
        n = e.KEY[code]
    elif code in e.BTN:
        n = e.BTN[code]
    else:
        return f'code{code}'
    return n[0] if isinstance(n, tuple) else n


# ---------------------------------------------------------------- 软映射

AXIS_FUNCS = ('roll', 'pitch', 'yaw')
STICK_FUNCS = ('throttle',)
SWITCH_FUNCS = ('arm', 'mode', 'buzzer', 'turtle')
ALL_FUNCS = AXIS_FUNCS + STICK_FUNCS + SWITCH_FUNCS

# 功能名的中文标签。键名一律保持英文（mapping.toml 里写的就是这些键），
# 只有界面与日志显示中文：roll 横滚 / pitch 俯仰 / yaw 偏航 / throttle 油门，
# arm 解锁 / mode 模式 / buzzer 回平 / turtle 翻正。
FUNC_CN = {'roll': '横滚', 'pitch': '俯仰', 'yaw': '偏航', 'throttle': '油门',
           'arm': '解锁', 'mode': '模式', 'buzzer': '回平', 'turtle': '翻正'}


class Mapping:
    """通道号 -> 功能 的软映射，外加每路的归一化参数。"""

    def __init__(self, data=None):
        self.data = data or {'device': {'match': '', 'backend': default_backend()}, 'funcs': {}}

    @property
    def funcs(self):
        return self.data.setdefault('funcs', {})

    def channel_meta(self, channels, index):
        for c in channels:
            if c.index == index:
                return c
        return None

    def apply(self, frame, channels):
        """把一帧原始值变成 {功能名: 值}。轴 -1..1，油门 0..1，开关 True/False 或档位序号。"""
        out = {}
        for name, spec in self.funcs.items():
            if spec.get('channel') is None:
                continue
            raw = frame.values.get(spec['channel'])
            if raw is None:
                continue
            meta = self.channel_meta(channels, spec['channel'])
            lo = spec.get('min', meta.min if meta else 0)
            hi = spec.get('max', meta.max if meta else 1)
            kind = spec.get('kind', 'axis')
            if kind == 'switch':
                mid = (lo + hi) / 2
                val = (raw > mid) if not spec.get('invert') else (raw < mid)
            elif kind == 'select':
                bands = spec.get('bands') or [lo + (hi - lo) * i / 3 for i in range(4)]
                val = 0
                for i, edge in enumerate(bands):
                    if raw >= edge:
                        val = i
                if spec.get('invert'):
                    val = len(bands) - 1 - val
                # 档位序号 -> 值。带语义的多档开关（模式）在这里换成模式号：
                # map = [0, 1, 2] 表示从最小档到最大档依次是 角度模式 / 半自稳 / 手动模式
                order = spec.get('map') or []
                if 0 <= val < len(order):
                    val = order[val]
            elif kind == 'range':
                span = (hi - lo) or 1
                val = (raw - lo) / span
                val = 1 - val if spec.get('invert') else val
                val = _deadband_scale(_curve(val, spec.get('expo', 0)), spec.get('deadband', 0), 0.0, 1.0)
            else:
                center = spec.get('center', (lo + hi) / 2)
                span = (hi - center) if raw >= center else (center - lo)
                val = 0.0 if span <= 0 else (raw - center) / span
                val = max(-1.0, min(1.0, val * spec.get('rate', 1.0) + spec.get('trim', 0.0)))
                val = _deadband_scale(_curve(val, spec.get('expo', 0)), spec.get('deadband', 0), -1.0, 1.0)
                if spec.get('invert'):
                    val = -val
            out[name] = val
        return out

    def learned_channels(self):
        return {s.get('channel') for s in self.funcs.values() if s.get('channel') is not None}

    def summary(self):
        lines = []
        for name in ALL_FUNCS:
            s = self.funcs.get(name)
            if not s or s.get('channel') is None:
                lines.append(f'  {FUNC_CN.get(name, name):<4} {name:<9} 未映射')
                continue
            extra = f"反={'是' if s.get('invert') else '否'}"
            if s.get('kind') == 'switch':
                extra += ' 开关'
            if s.get('kind') == 'select':
                extra += f" 档位x{len(s.get('bands') or [0, 0, 0, 0])}"
                if s.get('map'):
                    extra += ' 顺序' + '/'.join(str(int(m)) for m in s['map'])
            lines.append(f"  {FUNC_CN.get(name, name):<4} {name:<9} ch{s['channel']:<3} "
                         f"{s.get('kind', 'axis'):<7} "
                         f"{s.get('min')}..{s.get('max')} {extra}"
                         f"{'' if s.get('learned', True) else '  (未标定，请先跑 fpv_learn.py)'}")
        return '\n'.join(lines)


def _curve(x, expo):
    if not expo:
        return x
    return (1 - expo) * x + expo * x ** 3


def _deadband_scale(x, db, lo, hi):
    if db <= 0:
        return x
    if lo < 0:                                # 双向轴
        return 0.0 if abs(x) < db else math.copysign((abs(x) - db) / (1 - db), x)
    return 0.0 if x < db else (x - db) / (1 - db)


def empty_mapping(channels, backend=None, match=''):
    """按设备现有通道生成一份占位映射：通道号先按顺序填，等 fpv_learn.py 学一遍再定。"""
    data = {'device': {'match': match, 'backend': backend or default_backend()}, 'funcs': {}}
    order = [c.index for c in channels]
    idx = 0
    for name in AXIS_FUNCS + STICK_FUNCS:
        if idx < len(order):
            ch = order[idx]
            meta = channels[ch]
            data['funcs'][name] = {'channel': ch, 'kind': 'range' if name == 'throttle' else 'axis',
                                   'min': meta.min, 'max': meta.max, 'center': (meta.min + meta.max) // 2,
                                   'invert': False, 'deadband': 0.01, 'expo': 0.0, 'learned': False}
            idx += 1
    for name in SWITCH_FUNCS:
        if idx < len(order):
            meta = channels[order[idx]]
            data['funcs'][name] = {'channel': order[idx], 'kind': 'switch',
                                   'min': meta.min, 'max': meta.max, 'invert': False, 'learned': False}
            idx += 1
    return Mapping(data)
