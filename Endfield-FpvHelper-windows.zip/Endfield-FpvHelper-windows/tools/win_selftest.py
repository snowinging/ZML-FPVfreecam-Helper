#!/usr/bin/env python3
"""Windows 上的自检：不开窗、不动鼠标，逐条验证这次修复的内容。

    python tools\\win_selftest.py

检查项：
  1. UdpLink 能不能开起来（Windows 上对未绑定的 UDP socket 调 getsockname 会抛 WSAEINVAL）
  2. joy 后端的 SDL 是不是真的在独立线程里跑，泵频率和收帧是否正常
  3. 最关键的一条：SDL 在子线程泵的时候，Tk 的消息会不会被抢走
  4. Tk 回调里的异常能不能被钩子接住（否则出问题只会静默僵死）

第 3 项以前会失败（消息被 SDL 从线程队列里取走并派发），拖动窗口卡顿/闪退就是它。
"""
from __future__ import annotations

import ctypes
import ctypes.wintypes as wt
import math
import os
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault('PYGAME_HIDE_SUPPORT_PROMPT', '1')

from fpvhelper import channels as ch          # noqa: E402
from fpvhelper.link import UdpLink            # noqa: E402

PM_NOREMOVE = 0x0000
WM_APP = 0x8000
OK, BAD, SKIP = '[通过]', '[失败]', '[跳过]'
fails = []


def check(label, cond, extra=''):
    tag = OK if cond else BAD
    if not cond:
        fails.append(label)
    print(f'{tag} {label}' + (f'\n         {extra}' if extra else ''))


class StubJoy:
    """假摇杆，用来在没有硬件时也能把线程和消息隔离这两条跑完。"""

    def __init__(self):
        self.t0 = time.monotonic()
        self.axis_calls = 0

    def init(self): pass
    def get_guid(self): return 'stub'
    def get_instance_id(self): return 0
    def get_name(self): return 'STUB 假摇杆'
    def get_numhats(self): return 0
    def get_numbuttons(self): return 8
    def get_numaxes(self): return 6

    def get_axis(self, i):
        self.axis_calls += 1
        return 0.5 * math.sin((time.monotonic() - self.t0) * (0.9 + i * 0.13))

    def get_button(self, i):
        return 0


holder = {}


class StubSource(ch.JoySource):
    def _open(self, match, path):
        j = StubJoy()
        holder['joy'] = j
        return j


def main():
    print('=' * 70)
    print('1. UdpLink 能不能开起来')
    print('=' * 70)
    try:
        lk = UdpLink(47800)
        ep = lk.open()
        print(f'         本地端点 {ep}')
        check('UdpLink.open() 正常返回', True)
        check('能往外发状态包', bool(lk.send_state(100, 200, 300, 400)),
              f'seq={lk.seq}')
        lk.close()
    except Exception as exc:
        check('UdpLink.open() 正常返回', False, f'{type(exc).__name__}: {exc}')

    print()
    print('=' * 70)
    print('2. joy 后端：SDL 是否在独立线程里跑')
    print('=' * 70)
    main_tid = threading.get_ident()
    try:
        src = StubSource('STUB')
    except Exception as exc:
        check('JoySource 能起来', False, f'{type(exc).__name__}: {exc}')
        return report()
    check('JoySource 能起来', True, f'{src.path}  {src.device_name}')
    check('泵线程与主线程不是同一个', src._th.ident is not None and src._th.ident != main_tid,
          f'泵线程 id={src._th.ident}  主线程 id={main_tid}')
    check('通道/按键信息由子线程填好', len(src.channels) == 6 and len(src.keys) == 8,
          f'{len(src.channels)} 轴 {len(src.keys)} 键')

    t0 = time.monotonic()
    n0 = holder['joy'].axis_calls
    frames = 0
    while time.monotonic() - t0 < 1.0:
        if src.poll(0):
            frames += 1
        time.sleep(0.001)
    hz = (holder['joy'].axis_calls - n0) / 6.0
    check('泵频率在合理区间', 150 <= hz <= 600, f'{hz:.0f} 次/秒')
    check('主线程能取到帧', frames > 0, f'1 秒取到 {frames} 帧')

    print()
    print('=' * 70)
    print('3. 关键回归：SDL 在子线程泵时，Tk 的消息会不会被抢')
    print('=' * 70)
    try:
        import tkinter as tk
    except ImportError:
        check('执行消息隔离测试', False, '没有 tkinter')
        src.close()
        return report()

    root = tk.Tk()
    root.geometry('320x200+80+80')
    root.update()
    hwnd = ctypes.windll.user32.GetAncestor(root.winfo_id(), 2)
    time.sleep(0.4)

    for i in range(50):
        ctypes.windll.user32.PostMessageW(hwnd, WM_APP + 1, i, 0)
    msg = wt.MSG()
    before = bool(ctypes.windll.user32.PeekMessageW(
        ctypes.byref(msg), hwnd, 0, 0, PM_NOREMOVE))
    time.sleep(1.0)
    after = bool(ctypes.windll.user32.PeekMessageW(
        ctypes.byref(msg), hwnd, 0, 0, PM_NOREMOVE))
    check('SDL 泵着的时候 Tk 的消息一条没少', before and after,
          f'投递后 {int(before)} -> 泵 1 秒后 {int(after)}；这里出现 1 -> 0 就说明消息被抢了')
    root.destroy()

    src.close()
    time.sleep(0.3)
    check('close() 之后泵线程已退出', not src._th.is_alive())

    print()
    print('=' * 70)
    print('4. Tk 回调异常能不能被接住')
    print('=' * 70)
    root2 = tk.Tk()
    seen = []

    def hook(exc, val, tb):
        seen.append(f'{exc.__name__}: {val}')

    root2.report_callback_exception = hook

    def boom():
        raise ValueError('模拟内部错误')

    root2.after(10, boom)
    for _ in range(40):
        root2.update()
        time.sleep(0.01)
    check('after 回调里的异常被钩子接住', len(seen) == 1, seen[0] if seen else '没接住')
    root2.destroy()

    return report()


def report():
    print()
    print('=' * 70)
    if fails:
        print(f'有 {len(fails)} 项没通过：')
        for f in fails:
            print(f'  - {f}')
    else:
        print('全部通过')
    print('=' * 70)
    return 1 if fails else 0


if __name__ == '__main__':
    sys.exit(main())
