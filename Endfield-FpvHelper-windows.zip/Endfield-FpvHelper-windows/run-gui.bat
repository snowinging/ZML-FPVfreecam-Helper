@echo off
rem Windows: double-click this to launch the GUI.
rem It checks for pygame (installs it if missing), then starts the UI.
rem Command line args are passed through (e.g. --selftest, --send --port 47800).
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
  echo [X] python not found. Install Python 3.11+ first, and tick "Add to PATH".
  pause
  exit /b 1
)

python -c "import pygame" 2>nul
if errorlevel 1 (
  echo [*] pygame missing, installing...
  python -m pip install pygame
  if errorlevel 1 (
    echo [X] pip install pygame failed.
    pause
    exit /b 1
  )
)

python tools\ZML_FPVfreecam-HelperGUI.py %*
if errorlevel 1 pause
